@echo off
REM Fallback launcher: opens game.html with the default browser.
REM Keep this file ASCII-only (cmd reads .bat in the OEM code page).
start "" "%~dp0game.html"
